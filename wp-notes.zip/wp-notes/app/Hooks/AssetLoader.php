<?php

declare(strict_types=1);

namespace WPNotes\Hooks;

/**
 * Enqueues admin and public Vue 3 assets built by Vite.
 *
 * Vite writes a single manifest at dist/manifest.json covering both entry
 * points. PHP reads it to resolve hashed filenames at runtime.
 *
 * Manifest location:  dist/manifest.json
 * Manifest key format (full input path from project root):
 *   $manifest['resources/js/admin/main.js']['file']  → 'admin/admin-{hash}.js'
 *   $manifest['resources/js/admin/main.js']['css']   → ['admin/admin-{hash}.css']
 *
 * All 'file' and 'css' values are relative to dist/, so the full URL is:
 *   WP_NOTES_URL . 'dist/' . $entry['file']
 */
class AssetLoader
{
    /** @var bool Tracks whether the script_loader_tag filter has been registered. */
    private static bool $moduleFilterRegistered = false;

    /**
     * Add type="module" to WP Notes script tags so ES module imports resolve correctly.
     * Registered once on first enqueue; idempotent on subsequent calls.
     */
    private static function ensureModuleFilter(): void
    {
        if (self::$moduleFilterRegistered) {
            return;
        }

        add_filter('script_loader_tag', static function (string $tag, string $handle): string {
            if (in_array($handle, ['wp-notes-admin', 'wp-notes-public'], true)
                && strpos($tag, 'type="module"') === false
            ) {
                $tag = str_replace('<script ', '<script type="module" ', $tag);
            }
            return $tag;
        }, 10, 2);

        self::$moduleFilterRegistered = true;
    }

    /**
     * Enqueue admin Vue app scripts and styles.
     *
     * Hooked into admin_enqueue_scripts — only loads assets on this plugin's
     * wp-admin page. Returns silently on any other admin page or when the
     * Vite build has not been run yet.
     *
     * Injects window.wpNotesAdmin = { nonce, apiUrl, currentUser } for Vue.
     *
     * @param string $hook The current wp-admin page hook suffix.
     */
    public static function enqueueAdmin(string $hook): void
    {
        if (strpos($hook, wpillar_config('slug')) === false) {
            return;
        }

        $manifest = self::loadManifest();
        if ($manifest === null) {
            return;
        }

        self::ensureModuleFilter();

        $entry  = $manifest['resources/js/admin/main.js'] ?? null;
        $jsFile = $entry['file'] ?? null;

        if ($jsFile === null) {
            return;
        }

        $baseUrl = WP_NOTES_URL . 'dist/';

        wp_enqueue_script('wp-notes-admin', $baseUrl . $jsFile, [], null, true);

        foreach (($entry['css'] ?? []) as $i => $cssFile) {
            wp_enqueue_style('wp-notes-admin-style-' . $i, $baseUrl . $cssFile, [], null);
        }

        wp_localize_script('wp-notes-admin', 'wpNotesAdmin', [
            'nonce'       => wp_create_nonce('wp_rest'),
            'apiUrl'      => rest_url(wpillar_config('rest_namespace')),
            'currentUser' => get_current_user_id(),
        ]);
    }

    /**
     * Enqueue public Vue app scripts and styles.
     *
     * Called from the [wp_notes] shortcode and resources/views/public-page.php.
     * Idempotent — safe to call multiple times; skips if already enqueued.
     * Returns silently when the Vite build has not been run yet.
     *
     * Injects window.wpNotesPublic = { apiUrl } for Vue.
     */
    public static function enqueuePublic(): void
    {
        if (wp_script_is('wp-notes-public', 'enqueued')) {
            return;
        }

        $manifest = self::loadManifest();
        if ($manifest === null) {
            return;
        }

        self::ensureModuleFilter();

        $entry  = $manifest['resources/js/public/main.js'] ?? null;
        $jsFile = $entry['file'] ?? null;

        if ($jsFile === null) {
            return;
        }

        $baseUrl = WP_NOTES_URL . 'dist/';

        wp_enqueue_script('wp-notes-public', $baseUrl . $jsFile, [], null, true);

        foreach (($entry['css'] ?? []) as $i => $cssFile) {
            wp_enqueue_style('wp-notes-public-style-' . $i, $baseUrl . $cssFile, [], null);
        }

        // noteSlug is set when loaded on a clean-URL note detail page
        // (test.local/notes/{slug}). main.js uses it to navigate Vue Router
        // to /#/note/{slug} so NoteDetail renders instead of NoteGrid.
        wp_localize_script('wp-notes-public', 'wpNotesPublic', [
            'apiUrl'   => rest_url(wpillar_config('rest_namespace')),
            'noteSlug' => get_query_var('note_slug', ''),
        ]);
    }

    /**
     * Load and decode the Vite manifest from dist/manifest.json.
     * Returns null if the file does not exist or cannot be decoded.
     *
     * @return array<string, mixed>|null
     */
    private static function loadManifest(): ?array
    {
        $path = WP_NOTES_PATH . 'dist/manifest.json';

        if (!file_exists($path)) {
            return null;
        }

        $decoded = json_decode((string) file_get_contents($path), true);

        return is_array($decoded) ? $decoded : null;
    }
}
