<?php

declare(strict_types=1);

namespace WPNotes\Http\Policies;

use WPPillar\Framework\Auth\Policy;

/**
 * Permission policy for public note endpoints.
 *
 * These endpoints are intentionally unauthenticated — they serve read-only
 * access to published notes. Data security is enforced inside the controller
 * (status = 'published' filter is always applied; drafts are never returned).
 *
 * Cannot use the Router for public routes because the Router mandates nonce
 * verification on every route. Public callers (unauthenticated Vue frontend)
 * do not have a nonce.
 */
class NotePublicPolicy extends Policy
{
    /**
     * Grant access unconditionally — public read-only endpoint.
     * Security is enforced by the controller, not the permission layer.
     */
    public function authorize(string $capability = 'manage_options'): bool
    {
        return true;
    }

    /**
     * Return a callable for use as a register_rest_route permission_callback.
     * Ignores the WP_REST_Request argument WordPress passes to the callback.
     */
    public function permissionCallback(string $capability = 'manage_options'): callable
    {
        return static fn(): bool => true;
    }
}
