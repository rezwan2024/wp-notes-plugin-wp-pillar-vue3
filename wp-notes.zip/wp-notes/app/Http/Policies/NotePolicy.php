<?php

declare(strict_types=1);

namespace WPNotes\Http\Policies;

use WPPillar\Framework\Auth\Policy;

/**
 * Authorization policy for admin note endpoints.
 *
 * Used by the Router for all five admin REST routes:
 * GET/POST/GET{id}/PUT{id}/DELETE{id} under /wp-notes/v1/notes.
 *
 * The Router calls authorize() with no arguments, using the default
 * 'manage_options' capability — only WordPress administrators can proceed.
 */
class NotePolicy extends Policy
{
    /**
     * Allow access only to users with manage_options capability (administrators).
     */
    public function authorize(string $capability = 'manage_options'): bool
    {
        return parent::authorize($capability);
    }
}
