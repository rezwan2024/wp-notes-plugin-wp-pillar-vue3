<?php

declare(strict_types=1);

use WPNotes\Http\Controllers\NoteController;
use WPNotes\Http\Policies\NotePolicy;
use WPNotes\Http\Policies\NotePublicPolicy;
use WPPillar\Framework\Http\Request;
use WPPillar\Framework\Http\Router;

$namespace = wpillar_config('rest_namespace');

// ── Admin routes — nonce + manage_options required ────────────────────────
// All five routes go through the Router, which enforces nonce verification
// and NotePolicy::authorize() (manage_options) on every request.

$router = new Router($namespace, 'WPNotes\\Http\\Controllers\\');

$router->get('/notes',                     'NoteController@index',   NotePolicy::class);
$router->post('/notes',                    'NoteController@store',   NotePolicy::class);
$router->get('/notes/(?P<id>\d+)',         'NoteController@show',    NotePolicy::class);
$router->put('/notes/(?P<id>\d+)',         'NoteController@update',  NotePolicy::class);
$router->delete('/notes/(?P<id>\d+)',      'NoteController@destroy', NotePolicy::class);

// ── Public routes — no auth, published notes only ─────────────────────────
// Registered directly (not via Router) because the Router mandates nonce
// verification, which unauthenticated callers don't have.
// Security is enforced inside the controller (status = 'published' always applied).

$publicPermission = (new NotePublicPolicy())->permissionCallback();

register_rest_route($namespace, '/public/notes', [
    'methods'             => 'GET',
    'callback'            => static function (\WP_REST_Request $wpRequest) use ($namespace): \WP_REST_Response {
        $request    = new Request($wpRequest);
        $controller = new NoteController($request);
        return $controller->publicIndex($request);
    },
    'permission_callback' => $publicPermission,
]);

register_rest_route($namespace, '/public/notes/(?P<slug>[a-z0-9-]+)', [
    'methods'             => 'GET',
    'callback'            => static function (\WP_REST_Request $wpRequest): \WP_REST_Response {
        $request    = new Request($wpRequest);
        $controller = new NoteController($request);
        return $controller->publicShow($request);
    },
    'permission_callback' => $publicPermission,
]);
