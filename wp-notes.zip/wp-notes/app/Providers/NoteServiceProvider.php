<?php

declare(strict_types=1);

namespace WPNotes\Providers;

use WPNotes\Hooks\AssetLoader;
use WPPillar\Framework\Support\ServiceProvider;

/**
 * Main service provider for WP Notes.
 *
 * register() — REST routes loaded into rest_api_init (Phase 3).
 * boot()     — admin menu (Phase 5), assets, shortcode, rewrite rules (Phase 4).
 */
class NoteServiceProvider extends ServiceProvider
{
    /**
     * Register REST routes via the rest_api_init action.
     */
    public function register(): void
    {
        add_action('rest_api_init', static function (): void {
            require_once wpillar_config('plugin_path') . 'app/Http/routes.php';
        });
    }

    /**
     * Boot plugin functionality: assets, shortcode, rewrite rules, template redirect.
     * Admin menu page registration added in Phase 5.
     */
    public function boot(): void
    {
        // ── Admin menu page ───────────────────────────────────────────────
        add_action('admin_menu', static function (): void {
            add_menu_page(
                __('WP Notes', 'wp-notes'),
                __('WP Notes', 'wp-notes'),
                'manage_options',
                'wp-notes',
                static function (): void {
                    echo '<div id="wp-notes-admin"></div>';
                },
                'dashicons-edit-page',
                30
            );
        });

        // ── Admin assets ──────────────────────────────────────────────────
        add_action('admin_enqueue_scripts', [AssetLoader::class, 'enqueueAdmin']);

        // ── Public shortcode ──────────────────────────────────────────────
        // [wp_notes] → enqueues public Vue app + returns mount div.
        add_shortcode('wp_notes', static function (): string {
            AssetLoader::enqueuePublic();
            return '<div id="wp-notes-public"></div>';
        });

        // ── Rewrite rule for note detail URLs ─────────────────────────────
        // notes/{slug} → index.php?note_slug={slug}
        add_action('init', static function (): void {
            add_rewrite_rule('notes/([^/]+)/?$', 'index.php?note_slug=$matches[1]', 'top');
        });

        // Register note_slug as a recognised WordPress query variable.
        add_filter('query_vars', static function (array $vars): array {
            $vars[] = 'note_slug';
            return $vars;
        });

        // ── Template redirect for note detail pages ────────────────────────
        // When note_slug query var is set, serve the Vue public app page.
        add_action('template_redirect', static function (): void {
            if (get_query_var('note_slug', '') === '') {
                return;
            }

            require_once wpillar_config('plugin_path') . 'resources/views/public-page.php';
            exit;
        });
    }
}
