<?php

declare(strict_types=1);

namespace WPNotes\Models;

use WPPillar\Framework\Database\Model;
use WPPillar\Framework\Support\Str;

/**
 * Note Eloquent model.
 *
 * Table: wpn_notes (prefix 'wpn_' applied automatically by ORM::boot()).
 * Slug is auto-generated from title on create and regenerated on title change.
 */
class Note extends Model
{
    /** @var string ORM prepends wpn_ prefix → actual table: wpn_notes */
    protected $table = 'notes';

    /** @var bool Eloquent manages created_at and updated_at */
    public $timestamps = true;

    /** @var array<int, string> */
    protected $fillable = [
        'user_id',
        'title',
        'slug',
        'content',
        'category',
        'status',
    ];

    /**
     * Register model event listeners.
     * Using booted() avoids the need to call parent::boot() explicitly.
     */
    protected static function booted(): void
    {
        static::creating(static function (Note $note): void {
            $note->slug = static::generateUniqueSlug($note->title);
        });

        static::updating(static function (Note $note): void {
            if ($note->isDirty('title')) {
                $note->slug = static::generateUniqueSlug($note->title, (int) $note->id);
            }
        });
    }

    /**
     * Generate a URL-safe slug from a title, guaranteed unique in wpn_notes.
     * If the base slug exists, appends -2, -3, etc. until unique.
     *
     * @param int|null $excludeId Exclude this record ID from the uniqueness check (used on update).
     */
    private static function generateUniqueSlug(string $title, ?int $excludeId = null): string
    {
        $base    = Str::slug($title);
        $slug    = $base;
        $counter = 2;

        while (static::slugExists($slug, $excludeId)) {
            $slug = $base . '-' . $counter;
            $counter++;
        }

        return $slug;
    }

    /**
     * Check whether a slug already exists in the table.
     *
     * @param int|null $excludeId Exclude this ID so a record's own slug never blocks its own update.
     */
    private static function slugExists(string $slug, ?int $excludeId = null): bool
    {
        $query = static::where('slug', $slug);

        if ($excludeId !== null) {
            $query->where('id', '!=', $excludeId);
        }

        return $query->exists();
    }
}
