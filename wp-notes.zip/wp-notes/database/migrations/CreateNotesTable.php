<?php

declare(strict_types=1);

use Illuminate\Database\Schema\Blueprint;
use WPPillar\Framework\Database\Migration;
use WPPillar\Framework\Database\ORM;

/**
 * Creates the wpn_notes table.
 *
 * No namespace — loaded via Composer classmap so plugin-entry.php can reference
 * \CreateNotesTable::class without a namespace prefix.
 *
 * ORM::schema() uses the Capsule connection whose prefix is 'wpn_', so
 * create('notes') produces the wpn_notes table in the database.
 */
class CreateNotesTable extends Migration
{
    /**
     * Create the wpn_notes table with all required columns and indexes.
     * Guards with hasTable() so reactivation never throws "table already exists".
     */
    public function up(): void
    {
        if (ORM::schema()->hasTable('notes')) {
            return;
        }

        ORM::schema()->create('notes', static function (Blueprint $table): void {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('user_id');
            $table->string('title', 255);
            $table->string('slug', 255)->unique();
            $table->longText('content');
            $table->string('category', 50);
            $table->string('status', 20);
            $table->timestamps();

            $table->index('user_id');
            $table->index('status');
            $table->index('category');
        });
    }

    /**
     * Drop the wpn_notes table.
     */
    public function down(): void
    {
        ORM::schema()->dropIfExists('notes');
    }
}
