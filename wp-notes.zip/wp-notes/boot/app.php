<?php

declare(strict_types=1);

use WPNotes\Providers\NoteServiceProvider;
use WPPillar\Framework\Application;
use WPPillar\Framework\Database\ORM;

$app = Application::getInstance();

// Guard against double-boot within a single request.
if ($app->isBooted()) {
    return $app;
}

// Load plugin config and merge in runtime paths (set by plugin-entry.php constants).
$pluginConfig = require __DIR__ . '/../config/plugin.php';

$app->setConfig(array_merge($pluginConfig, [
    'plugin_path' => defined('WP_NOTES_PATH') ? WP_NOTES_PATH : dirname(__DIR__) . '/',
    'plugin_url'  => defined('WP_NOTES_URL')  ? WP_NOTES_URL  : '',
]));

// Bootstrap Eloquent ORM — uses WP DB constants + db_prefix from config.
ORM::boot($app->getConfig());

// Register and boot the application service provider.
$app->register([NoteServiceProvider::class]);
$app->boot();

return $app;
