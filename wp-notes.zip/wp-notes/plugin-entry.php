<?php

/**
 * Plugin Name:       WP Notes
 * Plugin URI:        https://example.com/wp-notes
 * Description:       A Notes Manager plugin built on WP Pillar framework. Tests Vue 3 + Vite + Eloquent ORM end-to-end.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * Author:            Rezwan
 * Author URI:        https://example.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       wp-notes
 * Domain Path:       /languages
 */

defined('ABSPATH') || exit;

// ── SECURITY 1 — PHP version check ────────────────────────────────────────
if (version_compare(PHP_VERSION, '8.0', '<')) {
    add_action('admin_notices', static function () {
        echo '<div class="notice notice-error"><p>';
        printf(
            '<strong>WP Notes</strong> requires PHP 8.0 or higher. ' .
            'Your server is running PHP %s. Please upgrade PHP or contact your host.',
            esc_html(PHP_VERSION)
        );
        echo '</p></div>';
    });
    return;
}

// ── SECURITY 2 — WordPress version check ──────────────────────────────────
if (function_exists('get_bloginfo') && version_compare(get_bloginfo('version'), '6.0', '<')) {
    add_action('admin_notices', static function () {
        echo '<div class="notice notice-error"><p>';
        echo '<strong>WP Notes</strong> requires WordPress 6.0 or higher. Please update WordPress.';
        echo '</p></div>';
    });
    return;
}

// ── COMPATIBILITY — Multisite not supported in v1.0 ───────────────────────
if (function_exists('is_multisite') && is_multisite()) {
    add_action('admin_notices', static function () {
        echo '<div class="notice notice-error"><p>';
        echo '<strong>WP Notes</strong> does not support WordPress Multisite in v1.0.';
        echo '</p></div>';
    });
    if (function_exists('deactivate_plugins')) {
        deactivate_plugins(plugin_basename(__FILE__));
    }
    return;
}

// ── PLUGIN CONSTANTS ──────────────────────────────────────────────────────
define('WP_NOTES_VERSION', '1.0.0');
define('WP_NOTES_PATH',    plugin_dir_path(__FILE__));
define('WP_NOTES_URL',     plugin_dir_url(__FILE__));

// ── AUTOLOADER ────────────────────────────────────────────────────────────
require_once __DIR__ . '/vendor/autoload.php';

use WPPillar\Framework\Console\Installer;

// ── LIFECYCLE HOOKS ───────────────────────────────────────────────────────

register_activation_hook(__FILE__, static function () {
    // Do NOT use boot/app.php here. Another WP Pillar plugin on the same site may
    // have already booted the Application singleton with a different db_prefix.
    // ORM::boot() has no "already booted" guard — calling it directly always
    // overrides the Capsule and ensures migrations use wpn_ prefix.
    $config = require __DIR__ . '/config/plugin.php';
    \WPPillar\Framework\Database\ORM::boot(array_merge($config, [
        'plugin_path' => WP_NOTES_PATH,
        'plugin_url'  => WP_NOTES_URL,
    ]));
    Installer::activate([\CreateNotesTable::class]);
    // Register rewrite rule before flushing — on first activation init has not
    // yet fired, so the NoteServiceProvider::boot() rule is not registered yet.
    add_rewrite_rule('notes/([^/]+)/?$', 'index.php?note_slug=$matches[1]', 'top');
    flush_rewrite_rules();
});

register_deactivation_hook(__FILE__, static function () {
    Installer::deactivate();
});

// WordPress serializes the uninstall callback — Closures cannot be serialized.
class WPNotesUninstaller
{
    public static function run(): void
    {
        require_once __DIR__ . '/vendor/autoload.php';
        require_once __DIR__ . '/boot/app.php';
        \WPPillar\Framework\Console\Installer::uninstall([\CreateNotesTable::class]);
    }
}

register_uninstall_hook(__FILE__, ['WPNotesUninstaller', 'run']);

// ── BOOT ──────────────────────────────────────────────────────────────────
add_action('plugins_loaded', static function () {
    require_once __DIR__ . '/boot/app.php';
}, 1);
