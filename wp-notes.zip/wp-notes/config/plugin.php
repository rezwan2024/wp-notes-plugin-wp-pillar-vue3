<?php

declare(strict_types=1);

/**
 * WP Notes plugin configuration.
 *
 * Returned as a plain array and merged into the Application config
 * by boot/app.php. Keys are accessed via wpillar_config('key').
 *
 * Never hardcode these values anywhere else in the plugin.
 */
return [
    'name'           => 'WP Notes',
    'slug'           => 'wp-notes',
    'version'        => '1.0.0',
    'db_prefix'      => 'wpn_',

    'rest_namespace' => 'wp-notes/v1',

    // Must match the Text Domain header in plugin-entry.php exactly.
    'text_domain'    => 'wp-notes',

    'min_php'        => '8.0',
    'min_wp'         => '6.0',
];
